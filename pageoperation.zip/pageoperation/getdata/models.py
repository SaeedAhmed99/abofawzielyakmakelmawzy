from django.db import models
from datetime import datetime

class Page(models.Model):
    page_id = models.CharField(max_length=150)
    page_url = models.CharField(max_length=150)

class Posts(models.Model):
    post_id = models.CharField(max_length=150)
    published_date = models.DateTimeField(default=datetime.now)
    post_url = models.CharField(max_length=180)
    type_post = models.CharField(max_length=100)
    message = models.CharField(max_length=1000)
    page = models.ForeignKey(Page, on_delete=models.CASCADE, related_name='page_post')

class Comments(models.Model):
    comment_id = models.CharField(max_length=150)
    published_date = models.DateTimeField(default=datetime.now)
    message = models.CharField(max_length=1000)
    post = models.ForeignKey(Posts, on_delete=models.CASCADE, related_name='post_comment')

class GetAllCommentOnPost(models.Model):
    comment_id = models.CharField(max_length=150)
    published_date = models.DateTimeField()
    message = models.CharField(max_length=1000)
    post = models.ForeignKey(Posts, on_delete=models.CASCADE, related_name='post_All_comment')
