from django.http.response import HttpResponse
from django.shortcuts import render
from django.http import HttpResponseRedirect
from . import models
import facebook
import requests
import json

token = '''EAAH5rqIU3GoBAJdkzBha9ztGAqePwMd3ETsr0u2x44LfAxwaqAW4uZC4EJZBvwRRqfs1hUIicpo3ZCX9LvpGuYKjYi2bgA8cvh4GPAgeyEOxqLBMnSASSrT453voHn5bHwjXwLMj4lA82SsoV1PXzJsaRw3M7iW8hy2EsoDcNh9APUuR2SMz9gpAo5LHgqTWCQUZA3dBRwM4BjZBFChFH'''


def indexPage(request):
    posts = models.Posts.objects.all()
    return render(request, 'getdata/index.html', {'posts': posts})



def addpost(request):
    return render(request, 'getdata/addpost.html')


def savepostdata(request):
    graph = facebook.GraphAPI(access_token=token)
    message = request.POST['message']
    a = graph.put_object('me', 'feed', message=message)
    page = models.Page.objects.first()
    obj = models.Posts()
    obj.post_id = a['id']
    obj.post_url = 'https://www.facebook.com/' + str(a['id'])
    obj.type_post = 'post with out caption'
    obj.message = message
    obj.page = page
    obj.save()

    return HttpResponseRedirect('/')


def addcomment(request, post_id):
    return render(request, 'getdata/addcomment.html', {'post_id': post_id})


def savecommentdata(request, post_id):
    graph = facebook.GraphAPI(access_token=token)
    message = request.POST['message']
    post = models.Posts.objects.get(pk=post_id)
    a = graph.put_object(post.post_id, 'comments', message=message)
    obj = models.Comments()
    obj.comment_id = a['id']
    obj.message = message
    obj.post = post
    obj.save()
    return HttpResponseRedirect('/')


def getallcomments(request, post_id):
    post = models.Posts.objects.get(pk=post_id)
    post_url = 'https://graph.facebook.com/{}/comments'.format(post.post_id)
    a = requests.get(post_url, params={'access_token': token})
    # print(a.text)
    jsoncomment = json.loads(a.text)
    allcomments = jsoncomment['data']
    # print(type(allcomments[0]))
    if len(allcomments) == 0:
        allcomments = 'not comments'
    # obj = models.GetAllCommentOnPost()
    # for comment in allcomments:
    #     print(comment)
    #     obj.comment_id = str(comment['id'])
    #     obj.published_date = comment['created_time']
    #     obj.message = comment['message']
    #     print(comment['message'])
    #     obj.post = post
    #     obj.save()
    return render(request, 'getdata/allcomments.html', {'comments': allcomments})


# enum {NONE, LIKE, LOVE, WOW, HAHA, SORRY, ANGRY}
def reactions(request, post_id):
    post = models.Posts.objects.get(pk=post_id)
    post_url = 'https://graph.facebook.com/{}?fields=reactions.summary(total_count)&access_token={}'.format(post.post_id, token)
    # a = requests.get(post_url)
    total_count = json.loads(requests.get(post_url).text)['reactions']['summary']['total_count']
    like_url = 'https://graph.facebook.com/{}?fields=reactions.type(LIKE).limit(0).summary(total_count)&access_token={}'.format(post.post_id, token)
    love_url = 'https://graph.facebook.com/{}?fields=reactions.type(LOVE).limit(0).summary(total_count)&access_token={}'.format(post.post_id, token)
    wow_url = 'https://graph.facebook.com/{}?fields=reactions.type(WOW).limit(0).summary(total_count)&access_token={}'.format(post.post_id, token)
    haha_url = 'https://graph.facebook.com/{}?fields=reactions.type(HAHA).limit(0).summary(total_count)&access_token={}'.format(post.post_id, token)
    none_url = 'https://graph.facebook.com/{}?fields=reactions.type(SAD).limit(0).summary(total_count)&access_token={}'.format(post.post_id, token)
    angry_url = 'https://graph.facebook.com/{}?fields=reactions.type(ANGRY).limit(0).summary(total_count)&access_token={}'.format(post.post_id, token)
    a = requests.get(post_url)
    print(total_count)
    context = {
        'total_reactions': total_count,
        'LIKE': json.loads(requests.get(like_url).text)['reactions']['summary']['total_count'],
        'LOVE': json.loads(requests.get(love_url).text)['reactions']['summary']['total_count'],
        'WOW': json.loads(requests.get(wow_url).text)['reactions']['summary']['total_count'],
        'HAHA': json.loads(requests.get(haha_url).text)['reactions']['summary']['total_count'],
        'SAD': json.loads(requests.get(none_url).text)['reactions']['summary']['total_count'],
        'ANGRY': json.loads(requests.get(angry_url).text)['reactions']['summary']['total_count'],
    }
    return render(request, 'getdata/reactions.html', context)

