from django.urls import path
from getdata import views

urlpatterns = [
    path('', views.indexPage, name='indexpage'),
    path('addpost/', views.addpost, name='addpost'),
    path('savepostdata/', views.savepostdata, name='savepostdata'),
    path('addcomment/<int:post_id>/', views.addcomment, name='addcomment'),
    path('savecommentdata/<int:post_id>/', views.savecommentdata, name='savecommentdata'),
    path('getallcomments/<int:post_id>/', views.getallcomments, name='getallcomments'),
    path('reactions/<int:post_id>/', views.reactions, name='reactions'),
]
